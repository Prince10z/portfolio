# Infinite Scroll Animation (Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ykadosh/pen/XWBKjEV](https://codepen.io/ykadosh/pen/XWBKjEV).

This is a pure CSS & HTML version of this React implementation - https://codepen.io/ykadosh/pen/KKezJzz

Note that for this to work with different content, your content must be duplicated.